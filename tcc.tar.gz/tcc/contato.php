<?php
include 'cabecalho.php';
?>

<h1> fale conosco pelo:</h1>
<h2>email:<br>1info2.araquari@gmail.com</h2>
<h2>telefone:<br>(47) 000000000</h2>